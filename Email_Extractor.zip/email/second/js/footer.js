// Write out standard footer and links
document.write('Copyright &copy; 2021 <a href="http://www.gkaim.com/">Vikash chaudhary</a> All Rights Reserved');
document.write( '<span class="pull-right">')
document.write(' &nbsp; <a href="/">Home</a>');
document.write(' &nbsp; <a href="/contact-us/">Contact Us</a>');
document.write(' &nbsp; <a href="/privacy-policy/">Privacy Policy</a>');
document.write(' &nbsp; <a href="/terms-conditions-disclaimer/">Terms & Conditions</a>');
